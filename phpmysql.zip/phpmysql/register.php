<?php 
include('includes/db.php'); // Include database connection


// Initialize variables
$error = '';
$success = false;
$username = $email = '';

if (isset($_POST['register'])) {
    // Capture form data
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'] ?? '';

    // Validation
    if (empty($username) || empty($email) || empty($password) || empty($confirm_password)) {
        $error = "Please fill in all fields.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Please enter a valid email address.";
    } elseif ($password !== $confirm_password) {
        $error = "Passwords do not match.";
    } elseif (strlen($password) < 8) {
        $error = "Password must be at least 8 characters long.";
    } else {
        // Hash the password for security
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // Check if the user already exists (using prepared statement)
        $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $error = "User with this email already exists.";
        } else {
            // Insert the new user (using prepared statement)
            $stmt = $conn->prepare("INSERT INTO users (username, email, password) VALUES (?, ?, ?)");
            $stmt->bind_param("sss", $username, $email, $hashed_password);
            
            if ($stmt->execute()) {
                $success = true;
                // Clear form fields
                $username = $email = '';
            } else {
                $error = "Error: " . $conn->error;
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register | Thrift Store</title>
    <style>
        :root {
            --primary-color: #6b4f4f;
            --primary-light: #8c6b6b;
            --text-dark: #4a3f35;
            --text-medium: #5a4e3c;
            --text-light: #7a6e5c;
            --bg-light: #fffaf3;
            --bg-lighter: #f9f6f1;
            --border-color: #d1c4b2;
            --error-color: #c44d4d;
            --success-color: #2e7d32;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f4f1ea;
            color: var(--text-dark);
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            line-height: 1.6;
            padding: 20px;
            background-image: linear-gradient(135deg, #f5f7fa 0%, #f4f1ea 100%);
        }
        
        .register-container {
            width: 100%;
            max-width: 500px;
            background: var(--bg-light);
            border-radius: 16px;
            box-shadow: 0 15px 35px rgba(0,0,0,0.1);
            padding: 40px;
            margin: 20px;
            position: relative;
            overflow: hidden;
        }
        
        .register-container::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 8px;
            background: linear-gradient(90deg, var(--primary-color), var(--primary-light));
        }
        
        .register-header {
            text-align: center;
            margin-bottom: 30px;
        }
        
        .register-header h1 {
            color: var(--primary-color);
            margin: 0 0 10px 0;
            font-size: 2.2rem;
            font-weight: 700;
        }
        
        .register-header p {
            color: var(--text-light);
            margin: 0;
            font-size: 1.05rem;
        }
        
        .form-group {
            margin-bottom: 25px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 10px;
            font-weight: 600;
            color: var(--text-medium);
            font-size: 0.95rem;
        }
        
        .form-group label.required:after {
            content: " *";
            color: var(--error-color);
        }
        
        .form-control {
            width: 100%;
            padding: 15px;
            border: 2px solid var(--border-color);
            border-radius: 10px;
            background-color: var(--bg-lighter);
            font-size: 1rem;
            transition: all 0.3s ease;
        }
        
        .form-control:focus {
            border-color: var(--primary-color);
            outline: none;
            box-shadow: 0 0 0 4px rgba(107, 79, 79, 0.1);
            background-color: white;
        }
        
        .btn-register {
            background-color: var(--primary-color);
            color: white;
            border: none;
            padding: 16px;
            border-radius: 10px;
            cursor: pointer;
            font-size: 1rem;
            font-weight: 600;
            width: 100%;
            transition: all 0.3s ease;
            margin-top: 10px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }
        
        .btn-register:hover {
            background-color: var(--primary-light);
            transform: translateY(-2px);
            box-shadow: 0 6px 10px rgba(0,0,0,0.15);
        }
        
        .login-link {
            text-align: center;
            margin-top: 25px;
            color: var(--text-light);
            font-size: 0.95rem;
        }
        
        .login-link a {
            color: var(--primary-color);
            text-decoration: none;
            font-weight: 600;
        }
        
        .login-link a:hover {
            text-decoration: underline;
        }
        
        .alert {
            padding: 15px;
            margin-bottom: 25px;
            border-radius: 10px;
            font-weight: 500;
            font-size: 0.95rem;
        }
        
        .alert.success {
            background-color: rgba(46, 125, 50, 0.1);
            color: var(--success-color);
            border-left: 4px solid var(--success-color);
        }
        
        .alert.error {
            background-color: rgba(198, 40, 40, 0.1);
            color: var(--error-color);
            border-left: 4px solid var(--error-color);
        }
        
        @media (max-width: 576px) {
            .register-container {
                padding: 30px 25px;
            }
        }
    </style>
</head>
<body>
    <div class="register-container">
        <div class="register-header">
            <h1>Create Account</h1>
            <p>Join our thrift store community</p>
        </div>
        
        <?php if ($success): ?>
            <div class="alert success">
                Registration successful! <a href="login.php">Login here</a>
            </div>
        <?php elseif (!empty($error)): ?>
            <div class="alert error"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
        
        <form method="POST" action="register.php">
            <div class="form-group">
                <label for="username" class="required">Username</label>
                <input type="text" id="username" name="username" class="form-control" 
                       placeholder="Enter your username" required
                       value="<?php echo htmlspecialchars($username); ?>">
            </div>
            
            <div class="form-group">
                <label for="email" class="required">Email Address</label>
                <input type="email" id="email" name="email" class="form-control" 
                       placeholder="Enter your email" required
                       value="<?php echo htmlspecialchars($email); ?>">
            </div>
            
            <div class="form-group">
                <label for="password" class="required">Password</label>
                <input type="password" id="password" name="password" class="form-control" 
                       placeholder="Create a password (min 8 characters)" required>
            </div>
            
            <div class="form-group">
                <label for="confirm_password" class="required">Confirm Password</label>
                <input type="password" id="confirm_password" name="confirm_password" 
                       class="form-control" placeholder="Confirm your password" required>
            </div>
            
            <button type="submit" name="register" class="btn-register">Register</button>
        </form>
        
        <div class="login-link">
            Already have an account? <a href="login.php">Sign in</a>
        </div>
    </div>
</body>
</html>

