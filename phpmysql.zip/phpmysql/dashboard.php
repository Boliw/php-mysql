<?php
session_start();
include('includes/db.php');

// Redirect to login if not authenticated
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Handle product deletion securely
if (isset($_GET['delete_id'])) {
    $delete_id = intval($_GET['delete_id']);

    // Verify the product belongs to the user
    $checkQuery = $conn->prepare("SELECT * FROM products WHERE id = ? AND user_id = ?");
    $checkQuery->bind_param("ii", $delete_id, $user_id);
    $checkQuery->execute();
    $result = $checkQuery->get_result();

    if ($result->num_rows > 0) {
        $deleteQuery = $conn->prepare("DELETE FROM products WHERE id = ?");
        $deleteQuery->bind_param("i", $delete_id);
        $deleteQuery->execute();
    }

    header("Location: dashboard.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Dashboard - Thrift Store</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background-color: #f4f1ea;
            margin: 0;
            padding: 0;
        }

        .navbar {
            background-color: #6b4f4f;
            color: white;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 30px;
        }

        .navbar .brand {
            font-size: 24px;
            font-weight: bold;
        }

        .navbar .nav-links a {
            color: white;
            margin-left: 20px;
            text-decoration: none;
            font-weight: bold;
        }

        .dashboard-container {
            max-width: 1200px;
            margin: 30px auto;
            padding: 0 20px;
        }

        .dashboard-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
        }

        .dashboard-title {
            font-size: 28px;
            color: #4a3f35;
        }

        .btn {
            background-color: #8c7b6a;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 6px;
            cursor: pointer;
            text-decoration: none;
            font-weight: bold;
            display: inline-block;
        }

        .btn:hover {
            background-color: #a3907a;
        }

        .products-table {
            width: 100%;
            border-collapse: collapse;
            background-color: #fffaf0;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.07);
        }

        .products-table th, 
        .products-table td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid #d1c4b2;
        }

        .products-table th {
            background-color: #6b4f4f;
            color: white;
        }

        .products-table tr:hover {
            background-color: #f9f6f1;
        }

        .action-btn {
            padding: 6px 12px;
            border-radius: 4px;
            text-decoration: none;
            font-size: 14px;
            margin-right: 5px;
        }

        .edit-btn {
            background-color: #5a8f5a;
            color: white;
        }

        .delete-btn {
            background-color: #c44d4d;
            color: white;
        }

        .product-image {
            width: 60px;
            height: 60px;
            object-fit: cover;
            border-radius: 4px;
        }

        footer {
            background-color: #6b4f4f;
            color: white;
            text-align: center;
            padding: 20px;
            margin-top: 40px;
        }
    </style>
</head>
<body>

<div class="navbar">
    <div class="brand">Thrift Store</div>
    <div class="nav-links">
        <a href="index.php">Home</a>
        <a href="add-product.php">Add Product</a>
        <a href="logout.php">Logout</a>
    </div>
</div>

<div class="dashboard-container">
    <div class="dashboard-header">
        <h1 class="dashboard-title">Dashboard</h1>
        <a href="add-product.php" class="btn">Add New Product</a>
    </div>

    <table class="products-table">
        <thead>
            <tr>
                <th>Image</th>
                <th>Name</th>
                <th>Description</th>
                <th>Price</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $query = $conn->prepare("SELECT * FROM products WHERE user_id = ?");
            $query->bind_param("i", $user_id);
            $query->execute();
            $result = $query->get_result();

            while ($product = $result->fetch_assoc()) {
                $imageUrl = !empty($product['image_url']) ? $product['image_url'] : 'https://placehold.co/600x400/png';
                
                echo '<tr>';
                echo '<td><img src="' . htmlspecialchars($imageUrl) . '" alt="' . htmlspecialchars($product['name']) . '" class="product-image"></td>';
                echo '<td>' . htmlspecialchars($product['name']) . '</td>';
                echo '<td>' . htmlspecialchars($product['description']) . '</td>';
                echo '<td>$' . number_format($product['price'], 2) . '</td>';
                echo '<td>';
                echo '<a href="edit-product.php?id=' . $product['id'] . '" class="action-btn edit-btn">Edit</a>';
                echo '<a href="dashboard.php?delete_id=' . $product['id'] . '" class="action-btn delete-btn" onclick="return confirm(\'Are you sure you want to delete this product?\')">Delete</a>';
                echo '</td>';
                echo '</tr>';
            }
            ?>
        </tbody>
    </table>
</div>

<footer>
    <p>&copy; <?php echo date('Y'); ?> Thrift Store. All rights reserved.</p>
</footer>

</body>
</html>
