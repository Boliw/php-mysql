<?php
session_start();
include('includes/db.php');

if (!isset($_SESSION['user_id'])) {
    echo "<script>alert('You must be logged in to add a product.'); window.location.href='login.php';</script>";
    exit;
}

if (isset($_POST['add_product'])) {
    $name = trim($_POST['name']);
    $description = trim($_POST['description']);
    $price = floatval($_POST['price']);
    $image_url = trim($_POST['image_url']);
    $category = trim($_POST['category']);
    $user_id = $_SESSION['user_id'];

    $query = "INSERT INTO products (name, description, price, image_url, category, user_id)
              VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ssdssi", $name, $description, $price, $image_url, $category, $user_id);

    if ($stmt->execute()) {
        echo "<script>alert('Product added successfully!'); window.location.href='index.php';</script>";
    } else {
        echo "Error: " . $stmt->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Product</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background-color: #f4f1ea;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 600px;
            background: #fffaf0;
            margin: 60px auto;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 6px 16px rgba(0,0,0,0.08);
        }

        h2 {
            text-align: center;
            color: #4a3f35;
            margin-bottom: 30px;
        }

        label {
            font-weight: bold;
            color: #6b4f4f;
            display: block;
            margin-bottom: 6px;
        }

        input[type="text"],
        input[type="number"],
        select,
        textarea {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 6px;
            background-color: #fff;
            font-size: 15px;
        }

        textarea {
            height: 100px;
            resize: vertical;
        }

        button {
            background-color: #8c7b6a;
            color: white;
            border: none;
            padding: 12px 20px;
            border-radius: 6px;
            cursor: pointer;
            width: 100%;
            font-size: 16px;
        }

        button:hover {
            background-color: #7a6a5b;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Add a New Product</h2>
        <form method="POST" action="add-product.php">
            <label for="name">Product Name:</label>
            <input type="text" id="name" name="name" required>

            <label for="description">Description:</label>
            <textarea id="description" name="description" required></textarea>

            <label for="price">Price:</label>
            <input type="number" id="price" name="price" step="0.01" required>

            <label for="image_url">Image URL (Optional):</label>
            <input type="text" id="image_url" name="image_url">

            <label for="category">Category:</label>
            <select name="category" id="category" required>
                <option value="">Select Category</option>
                <option value="Clothing">Clothing</option>
                <option value="Shoes">Shoes</option>
                <option value="Accessories">Accessories</option>
                <option value="Electronics">Electronics</option>
                <option value="Books">Books</option>
            </select>

            <button type="submit" name="add_product">Add Product</button>
        </form>
    </div>
</body>
</html>
