<?php
session_start();
include('includes/db.php');

$message = "";

if (isset($_POST['login'])) {
    $username_email = $_POST['username'];
    $password = $_POST['password'];

    if (empty($username_email) || empty($password)) {
        $message = "Please fill in both fields.";
    } else {
        $sql = "SELECT * FROM users WHERE username = '$username_email' OR email = '$username_email'";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            $user = $result->fetch_assoc();
            if (password_verify($password, $user['password'])) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                header("Location: dashboard.php");
                exit();
            } else {
                $message = "Incorrect password.";
            }
        } else {
            $message = "User not found.";
        }
    }
}
?>



<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Login - Thrift Store</title>
  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
      background-color: #f4f1ea;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
      margin: 0;
    }

    .main-container {
      display: flex;
      flex-direction: column;
      align-items: center;
      text-align: center;
    }

    .logo {
      font-size: 36px;
      font-weight: bold;
      color: #6b4f4f;
      margin-bottom: 20px;
    }

    .login-container {
      background-color: #fffaf0;
      padding: 40px;
      border-radius: 10px;
      box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
      max-width: 500px;
      width: 100%;
    }

    h2 {
      text-align: center;
      color: #4a3f35;
      margin-bottom: 20px;
      font-size: 24px;
    }

    .message {
      color: #a33;
      margin-bottom: 15px;
      font-size: 14px;
    }

    form {
      display: flex;
      flex-direction: column;
      gap: 15px;
    }

    input[type="text"],
    input[type="password"] {
      padding: 12px;
      border: 1px solid #d1c4b2;
      border-radius: 6px;
      background-color: #f9f6f1;
      font-size: 16px;
    }

    button {
      padding: 12px;
      background-color: #8c7b6a;
      color: white;
      border: none;
      border-radius: 6px;
      cursor: pointer;
      font-size: 16px;
      font-weight: bold;
    }

    button:hover {
      background-color: #a3907a;
    }

    .signup-link {
      margin-top: 20px;
      font-size: 14px;
    }

    .signup-link a {
      color: #6b4f4f;
      text-decoration: none;
    }

    .signup-link a:hover {
      text-decoration: underline;
    }
  </style>
</head>
<body>

  <div class="main-container">
    <div class="logo">Thrift Store</div>
    <div class="login-container">
      <h2>Log In</h2>
      <?php if (!empty($message)) echo "<div class='message'>$message</div>"; ?>
      <form method="POST" action="login.php">
        <input type="text" name="username" placeholder="Username or Email" required>
        <input type="password" name="password" placeholder="Password" required>
        <button type="submit" name="login">Log In</button>
      </form>
      <div class="signup-link">
        Don't have an account? <a href="register.php">Sign up</a>
      </div>
    </div>
  </div>

</body>
</html>

