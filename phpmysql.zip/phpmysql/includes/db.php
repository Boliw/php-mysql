<?php
// Database configuration
$host = 'localhost';      // Database host
$dbname = 'thrift_store'; // Database name
$username = 'root';       // Database username
$password = '';           // Database password

// Create connection
$conn = mysqli_connect($host, $username, $password, $dbname);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Set charset to utf8
mysqli_set_charset($conn, "utf8");
?>