<?php
session_start();
include('includes/db.php');

// Redirect to login if not authenticated
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Get product ID from URL
$product_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Fetch product details
$query = "SELECT p.*, u.username as seller_name 
          FROM products p 
          JOIN users u ON p.user_id = u.id 
          WHERE p.id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $product_id);
$stmt->execute();
$result = $stmt->get_result();
$product = $result->fetch_assoc();

if (!$product) {
    header("Location: index.php");
    exit();
}

// Handle add to cart
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_to_cart'])) {
    $user_id = $_SESSION['user_id'];
    $quantity = isset($_POST['quantity']) ? intval($_POST['quantity']) : 1;

    // Check if item already in cart
    $check_query = "SELECT * FROM cart_items WHERE user_id = $user_id AND product_id = $product_id";
    $check_result = mysqli_query($conn, $check_query);

    if (mysqli_num_rows($check_result) > 0) {
        $update_query = "UPDATE cart_items SET quantity = quantity + $quantity WHERE user_id = $user_id AND product_id = $product_id";
        mysqli_query($conn, $update_query);
    } else {
        $insert_query = "INSERT INTO cart_items (user_id, product_id, quantity) VALUES ($user_id, $product_id, $quantity)";
        mysqli_query($conn, $insert_query);
    }

    header("Location: cart.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($product['name']); ?> - Thrift Store</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background-color: #f4f1ea;
            margin: 0;
            padding: 0;
            color: #4a3f35;
        }

        .navbar {
            background-color: #6b4f4f;
            color: white;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 30px;
        }

        .navbar .brand {
            font-size: 24px;
            font-weight: bold;
        }

        .navbar .nav-links a {
            color: white;
            margin-left: 20px;
            text-decoration: none;
            font-weight: bold;
        }

        .product-container {
            max-width: 1200px;
            margin: 30px auto;
            padding: 0 20px;
            display: flex;
            gap: 40px;
        }

        .product-images {
            flex: 1;
            max-width: 600px;
        }

        .main-image {
            width: 100%;
            height: 500px;
            object-fit: contain;
            background-color: #f9f6f1;
            border-radius: 8px;
            margin-bottom: 15px;
        }

        .thumbnail-container {
            display: flex;
            gap: 10px;
        }

        .thumbnail {
            width: 80px;
            height: 80px;
            object-fit: cover;
            border-radius: 4px;
            cursor: pointer;
            border: 2px solid transparent;
        }

        .thumbnail:hover, .thumbnail.active {
            border-color: #8c7b6a;
        }

        .product-details {
            flex: 1;
            max-width: 500px;
        }

        .product-title {
            font-size: 28px;
            margin: 0 0 10px;
        }

        .product-price {
            font-size: 24px;
            font-weight: bold;
            color: #8c7b6a;
            margin: 20px 0;
        }

        .product-seller {
            margin: 20px 0;
            font-size: 16px;
        }

        .product-seller a {
            color: #6b4f4f;
            font-weight: bold;
            text-decoration: none;
        }

        .product-seller a:hover {
            text-decoration: underline;
        }

        .product-description {
            margin: 30px 0;
            line-height: 1.6;
        }

        .add-to-cart {
            display: flex;
            gap: 15px;
            margin: 30px 0;
        }

        .quantity-selector {
            display: flex;
            align-items: center;
            border: 1px solid #d1c4b2;
            border-radius: 6px;
            padding: 5px;
        }

        .quantity-selector button {
            background: none;
            border: none;
            font-size: 18px;
            width: 30px;
            height: 30px;
            cursor: pointer;
            color: #6b4f4f;
        }

        .quantity-selector input {
            width: 50px;
            text-align: center;
            border: none;
            font-size: 16px;
        }

        .add-to-cart-btn {
            background-color: #8c7b6a;
            color: white;
            border: none;
            padding: 0 30px;
            border-radius: 6px;
            cursor: pointer;
            font-size: 16px;
            font-weight: bold;
            transition: background-color 0.3s;
        }

        .add-to-cart-btn:hover {
            background-color: #a3907a;
        }

        .product-meta {
            margin-top: 40px;
            border-top: 1px solid #d1c4b2;
            padding-top: 20px;
        }

        .meta-item {
            margin-bottom: 10px;
            font-size: 14px;
        }

        .meta-label {
            font-weight: bold;
            display: inline-block;
            width: 120px;
        }

        @media (max-width: 768px) {
            .product-container {
                flex-direction: column;
            }

            .product-images, .product-details {
                max-width: 100%;
            }
        }
    </style>
</head>
<body>

<div class="navbar">
    <div class="brand">Thrift Store</div>
    <div class="nav-links">
        <a href="index.php">Home</a>
        <a href="#">Categories</a>
        <a href="#">Deals</a>
        <?php if (isset($_SESSION['user_id'])): ?>
            <a href="dashboard.php">Dashboard</a>
            <a href="cart.php"><i class="fas fa-shopping-cart"></i> Cart</a>
            <a href="logout.php">Logout</a>
        <?php else: ?>
            <a href="login.php">Login</a>
            <a href="register.php">Register</a>
        <?php endif; ?>
    </div>
</div>

<div class="product-container">
    <div class="product-images">
        <img src="<?php echo !empty($product['image_url']) ? htmlspecialchars($product['image_url']) : 'https://placehold.co/600x600/png'; ?>" 
             alt="<?php echo htmlspecialchars($product['name']); ?>" 
             class="main-image">
        <div class="thumbnail-container">
            <!-- You can add more thumbnails here if you have multiple images -->
            <img src="<?php echo !empty($product['image_url']) ? htmlspecialchars($product['image_url']) : 'https://placehold.co/600x600/png'; ?>" 
                 alt="<?php echo htmlspecialchars($product['name']); ?>" 
                 class="thumbnail active">
        </div>
    </div>

    <div class="product-details">
        <h1 class="product-title"><?php echo htmlspecialchars($product['name']); ?></h1>
        
        <div class="product-price">$<?php echo number_format($product['price'], 2); ?></div>
        
        <div class="product-seller">
            Sold by: <a href="#"><?php echo htmlspecialchars($product['seller_name']); ?></a>
        </div>
        
        <div class="product-description">
            <?php echo nl2br(htmlspecialchars($product['description'])); ?>
        </div>
        
        <form method="POST" action="product-details.php?id=<?php echo $product_id; ?>">
            <div class="add-to-cart">
                <div class="quantity-selector">
                    <button type="button" onclick="this.parentNode.querySelector('input[type=number]').stepDown()">-</button>
                    <input type="number" name="quantity" value="1" min="1" max="10">
                    <button type="button" onclick="this.parentNode.querySelector('input[type=number]').stepUp()">+</button>
                </div>
                <button type="submit" name="add_to_cart" class="add-to-cart-btn">Add to Cart</button>
            </div>
        </form>
        
        <div class="product-meta">
            <div class="meta-item">
                <span class="meta-label">Category:</span>
                <?php echo htmlspecialchars($product['category']); ?>
            </div>
            <div class="meta-item">
                <span class="meta-label">Condition:</span>
                <!-- You can add condition field to your products table -->
                Good
            </div>
            <div class="meta-item">
                <span class="meta-label">Shipping:</span>
                Free shipping
            </div>
        </div>
    </div>
</div>

</body>
</html>