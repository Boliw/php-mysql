<?php
session_start();
include('includes/db.php');

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_id = $_SESSION['user_id'];

// Handle quantity updates
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['update_quantity'])) {
        $item_id = intval($_POST['item_id']);
        $quantity = intval($_POST['quantity']);
        
        if ($quantity > 0) {
            $update_query = "UPDATE cart_items SET quantity = $quantity WHERE id = $item_id AND user_id = $user_id";
            mysqli_query($conn, $update_query);
        } else {
            $delete_query = "DELETE FROM cart_items WHERE id = $item_id AND user_id = $user_id";
            mysqli_query($conn, $delete_query);
        }
    } elseif (isset($_POST['remove_item'])) {
        $item_id = intval($_POST['item_id']);
        $delete_query = "DELETE FROM cart_items WHERE id = $item_id AND user_id = $user_id";
        mysqli_query($conn, $delete_query);
    }
    
    header("Location: cart.php");
    exit;
}

// Get cart items with product details
$cart_query = "SELECT ci.id as cart_item_id, ci.quantity, p.id as product_id, p.name, p.price, p.image_url 
               FROM cart_items ci 
               JOIN products p ON ci.product_id = p.id 
               WHERE ci.user_id = $user_id";
$cart_result = mysqli_query($conn, $cart_query);

$total = 0;
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Your Shopping Cart</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
      background-color: #f4f1ea;
      margin: 0;
      padding: 0;
    }
    
    .navbar {
  background-color: #6b4f4f;
  color: white;
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 15px 30px;
}

.brand {
  font-size: 24px;
  font-weight: bold;
}

.nav-links {
  display: flex;
  gap: 20px;
}

.nav-links a {
  color: white;
  text-decoration: none;
  font-weight: 500;
  transition: color 0.3s ease;
}

.nav-links a:hover {
  color: #e0cfc2;
}

    
    .container {
      max-width: 1000px;
      margin: 30px auto;
      padding: 20px;
      background-color: white;
      border-radius: 8px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    }
    
    h1 {
      color: #4a3f35;
      border-bottom: 1px solid #e9e4d4;
      padding-bottom: 10px;
    }
    
    .cart-item {
      display: flex;
      align-items: center;
      padding: 20px 0;
      border-bottom: 1px solid #e9e4d4;
    }
    
    .cart-item img {
      width: 100px;
      height: 100px;
      object-fit: contain;
      margin-right: 20px;
      background-color: #f9f6f1;
      border-radius: 4px;
    }
    
    .item-details {
      flex: 1;
    }
    
    .item-details h3 {
      margin: 0 0 5px;
      color: #4a3f35;
    }
    
    .item-price {
      font-weight: bold;
      color: #8c7b6a;
      margin-bottom: 10px;
    }
    
    .quantity-control {
      display: flex;
      align-items: center;
    }
    
    .quantity-control input {
      width: 50px;
      text-align: center;
      margin: 0 10px;
      padding: 5px;
      border: 1px solid #ddd;
      border-radius: 4px;
    }
    
    .quantity-control button {
      background-color: #8c7b6a;
      color: white;
      border: none;
      width: 30px;
      height: 30px;
      border-radius: 4px;
      cursor: pointer;
    }
    
    .remove-btn {
      background-color: #ff6b6b;
      color: white;
      border: none;
      padding: 8px 15px;
      border-radius: 4px;
      cursor: pointer;
      margin-left: 20px;
    }
    
    .cart-summary {
      margin-top: 30px;
      text-align: right;
    }
    
    .total {
      font-size: 20px;
      font-weight: bold;
      color: #4a3f35;
    }
    
    .checkout-btn {
      background-color: #6b4f4f;
      color: white;
      border: none;
      padding: 12px 25px;
      border-radius: 6px;
      font-size: 16px;
      cursor: pointer;
      margin-top: 20px;
    }
    
    .empty-cart {
      text-align: center;
      padding: 50px;
      color: #6b4f4f;
    }
    
    .empty-cart i {
      font-size: 50px;
      margin-bottom: 20px;
    }


  </style>
</head>
<body>

<div class="navbar">
  <div class="brand">Thrift Store</div>
  <div class="nav-links">
    <a href="index.php">Home</a>
    <a href="#">Categories</a>
    <a href="#">Deals</a>
    <?php if (isset($_SESSION['user_id'])): ?>
      <a href="dashboard.php">Dashboard</a>
      <a href="cart.php">Cart</a>
      <a href="logout.php">Logout</a>
    <?php else: ?>
      <a href="login.php">Login</a>
      <a href="register.php">Register</a>
    <?php endif; ?>
  </div>
</div>

<div class="container">
  <h1>Your Shopping Cart</h1>
  
  <?php if (mysqli_num_rows($cart_result) > 0): ?>
    <?php while ($item = mysqli_fetch_assoc($cart_result)): ?>
      <?php 
      $subtotal = $item['price'] * $item['quantity'];
      $total += $subtotal;
      $imageUrl = !empty($item['image_url']) ? $item['image_url'] : 'https://placehold.co/100x100/png';
      ?>
      
      <div class="cart-item">
        <img src="<?php echo $imageUrl; ?>" alt="<?php echo htmlspecialchars($item['name']); ?>">
        <div class="item-details">
          <h3><?php echo htmlspecialchars($item['name']); ?></h3>
          <div class="item-price">$<?php echo number_format($item['price'], 2); ?></div>
          
          <form method="POST" action="cart.php" style="display: inline;">
            <input type="hidden" name="item_id" value="<?php echo $item['cart_item_id']; ?>">
            <div class="quantity-control">
              <button type="submit" name="update_quantity" onclick="this.form.quantity.value=<?php echo $item['quantity']-1; ?>">-</button>
              <input type="number" name="quantity" value="<?php echo $item['quantity']; ?>" min="1">
              <button type="submit" name="update_quantity" onclick="this.form.quantity.value=<?php echo $item['quantity']+1; ?>">+</button>
            </div>
          </form>
          
          <form method="POST" action="cart.php" style="display: inline;">
            <input type="hidden" name="item_id" value="<?php echo $item['cart_item_id']; ?>">
            <button type="submit" name="remove_item" class="remove-btn">Remove</button>
          </form>
          
          <div style="float: right;">
            <strong>$<?php echo number_format($subtotal, 2); ?></strong>
          </div>
        </div>
      </div>
    <?php endwhile; ?>
    
    <div class="cart-summary">
      <div class="total">Total: $<?php echo number_format($total, 2); ?></div>
      <button class="checkout-btn">Proceed to Checkout</button>
    </div>
  <?php else: ?>
    <div class="empty-cart">
      <i class="fas fa-shopping-cart"></i>
      <h2>Your cart is empty</h2>
      <p>Looks like you haven't added any items to your cart yet.</p>
      <a href="index.php" style="display: inline-block; margin-top: 20px; padding: 10px 20px; background-color: #8c7b6a; color: white; text-decoration: none; border-radius: 4px;">Continue Shopping</a>
    </div>
  <?php endif; ?>
</div>

</body>
</html>