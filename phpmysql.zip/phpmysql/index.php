<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}
include('includes/db.php');


// Count cart items if logged in
$cart_count = 0;
if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
    $count_query = "SELECT SUM(quantity) AS total FROM cart_items WHERE user_id = $user_id";
    $count_result = mysqli_query($conn, $count_query);
    $row = mysqli_fetch_assoc($count_result);
    $cart_count = $row['total'] ?? 0;
}

// Handle Add to Cart functionality
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_to_cart'])) {
    if (!isset($_SESSION['user_id'])) {
        header("Location: login.php");
        exit;
    }

    $user_id = $_SESSION['user_id'];
    $product_id = intval($_POST['product_id']);

    $check_query = "SELECT * FROM cart_items WHERE user_id = $user_id AND product_id = $product_id";
    $check_result = mysqli_query($conn, $check_query);

    if (mysqli_num_rows($check_result) > 0) {
        $update_query = "UPDATE cart_items SET quantity = quantity + 1 WHERE user_id = $user_id AND product_id = $product_id";
        mysqli_query($conn, $update_query);
    } else {
        $insert_query = "INSERT INTO cart_items (user_id, product_id, quantity) VALUES ($user_id, $product_id, 1)";
        mysqli_query($conn, $insert_query);
    }

    header("Location: index.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Thrift Store - Home</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
  <style>
    .add-cart-btn {
  background-color: #6b4f4f;
  color: white;
  border: none;
  padding: 10px 18px;
  border-radius: 8px;
  cursor: pointer;
  font-weight: bold;
  font-size: 14px;
  display: inline-flex;
  align-items: center;
  gap: 8px;
  transition: background-color 0.3s ease, transform 0.2s ease, box-shadow 0.3s ease;
  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
}

.add-cart-btn:hover {
  background-color: #8c7b6a;
  transform: scale(1.05);
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
}

@media screen and (max-width: 600px) {
  .add-cart-btn {
    width: 100%;
    justify-content: center;
  }
}

    body {
      
      font-family: 'Segoe UI', sans-serif;
      background-color: #f4f1ea;
      margin: 0;
      padding: 0;
    }

    .navbar {
      background-color: #6b4f4f;
      color: white;
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 15px 30px;
      
    }

    .navbar .brand {
      font-size: 24px;
      font-weight: bold;
    }

    .navbar .nav-links a {
      color: white;
      margin-left: 20px;
      text-decoration: none;
      font-weight: bold;
    }

    .cart-button {
      background-color: #8c7b6a;
      padding: 8px 14px;
      border-radius: 6px;
      font-weight: bold;
      display: inline-flex;
      align-items: center;
      gap: 8px;
      color: white;
      text-decoration: none;
      transition: background-color 0.3s ease;
    }

    .cart-button:hover {
      background-color: #a18c7a;
    }

    .hero-section {
  background-image: url('https://images.unsplash.com/photo-1568085823039-e823e87197e3?q=80&w=3540&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D'); /* Replace with your image URL */
  background-size: cover;
  background-position: center;
  height: 400px;
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;
}

.hero-text-box {
  background-color: rgba(255, 255, 255, 0.85);
  padding: 30px 40px;
  border-radius: 10px;
  text-align: center;
  max-width: 600px;
  box-shadow: 0 8px 20px rgba(0, 0, 0, 0.15);
}

.hero-text-box h1 {
  margin: 0;
  font-size: 36px;
  color: #4a3f35;
}

.hero-text-box p {
  margin: 10px 0 20px;
  font-size: 18px;
  color: #6b4f4f;
}

.hero-btn {
  background-color: #6b4f4f;
  color: white;
  padding: 12px 25px;
  border: none;
  text-decoration: none;
  border-radius: 6px;
  font-size: 16px;
  cursor: pointer;
  display: inline-block;
  transition: background-color 0.3s ease;
}

.hero-btn:hover {
  background-color: #4a3f35;
}


    .categories {
      display: flex;
      justify-content: center;
      flex-wrap: wrap;
      padding: 30px;
      background-color: #fffaf0;
    }

    .category {
      background: #f9f6f1;
      margin: 10px;
      padding: 20px;
      border-radius: 8px;
      width: 120px;
      text-align: center;
      box-shadow: 0 4px 12px rgba(0,0,0,0.05);
      cursor: pointer;
      text-decoration: none;
      color: #4a3f35;
      font-weight: bold;
    }

    .category i {
      font-size: 24px;
      color: #6b4f4f;
      margin-bottom: 8px;
    }

    .product-section {
      display: flex;
      flex-direction: column;
      gap: 20px;
      padding: 40px;
      max-width: 1000px;
      margin: auto;
    }

    .product-card {
      display: flex;
      align-items: flex-start;
      background-color: #fff;
      border-radius: 12px;
      box-shadow: 0 4px 16px rgba(0, 0, 0, 0.08);
      overflow: hidden;
      padding: 16px;
      gap: 20px;
      transition: transform 0.2s ease-in-out;
      flex-wrap: wrap;
    }

    .product-card:hover {
      transform: scale(1.02);
    }

    .product-card img {
      width: 180px;
      height: 180px;
      object-fit: contain;
      background-color: #f9f6f1;
      border-radius: 8px;
      flex-shrink: 0;
    }

    .product-info {
      flex: 1;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
    }

    .product-info h3 {
      font-size: 20px;
      color: #4a3f35;
      margin: 0 0 8px;
    }

    .product-info p {
      font-size: 14px;
      color: #6b4f4f;
      margin: 0 0 12px;
      max-height: 50px;
      overflow: hidden;
    }

    .product-info .price {
      font-weight: bold;
      color: #8c7b6a;
      margin-bottom: 12px;
    }

    .product-info button {
      background-color: #8c7b6a;
      color: white;
      border: none;
      padding: 10px 16px;
      border-radius: 6px;
      cursor: pointer;
      width: fit-content;
    }

    @media screen and (max-width: 600px) {
      .product-card {
        flex-direction: column;
        align-items: center;
        text-align: center;
      }

      .product-info {
        align-items: center;
      }

      .product-info p {
        max-height: none;
      }

      .product-info button {
        width: 100%;
      }
    }

    footer {
      background-color: #6b4f4f;
      color: white;
      text-align: center;
      padding: 20px;
      margin-top: 40px;
    }
    .footer-links {
  margin-top: 10px;
  display: flex;
  gap: 12px;
  justify-content: center;
  flex-wrap: wrap;
}

.footer-links a {
  background-color: #8c7b6a;
  color: white;
  padding: 8px 14px;
  border-radius: 6px;
  text-decoration: none;
  font-weight: 600;
  font-size: 14px;
  transition: background-color 0.3s ease;
}

.footer-links a:hover {
  background-color: #a18c7a;
}

  </style>
</head>
<body>

<div class="navbar">
  <div class="brand">Thrift Store</div>
  <div class="nav-links">
    <a href="index.php">Home</a>
    <a href="#">Categories</a>
    <a href="#">Deals</a>
    <?php if (isset($_SESSION['user_id'])): ?>
      <a href="dashboard.php">Dashboard</a>
      <a href="cart.php" class="cart-button">
        <i class="fas fa-shopping-cart"></i> Cart (<?php echo $cart_count; ?>)
      </a>
      <a href="logout.php">Logout</a>
    <?php else: ?>
      <a href="login.php">Login</a>
      <a href="register.php">Register</a>
    <?php endif; ?>
  </div>
</div>

<div class="hero-section">
  <div class="hero-text-box">
    <h1>Welcome to Thrift Store</h1>
    <p>Discover great deals on pre-loved treasures</p>
    <a href="index.php" class="hero-btn">Shop Now</a>
  </div>
</div>

<div class="categories">
  <a href="index.php?category=Clothing" class="category"><i class="fas fa-tshirt"></i><br>Clothing</a>
  <a href="index.php?category=Shoes" class="category"><i class="fas fa-shoe-prints"></i><br>Shoes</a>
  <a href="index.php?category=Accessories" class="category"><i class="fas fa-gem"></i><br>Accessories</a>
  <a href="index.php?category=Electronics" class="category"><i class="fas fa-laptop"></i><br>Electronics</a>
  <a href="index.php?category=Books" class="category"><i class="fas fa-book"></i><br>Books</a>
  <a href="index.php" class="category"><i class="fas fa-store"></i><br>All</a>
</div>

<div class="product-section">
  <?php
  $filter = "";
  if (isset($_GET['category'])) {
      $category = mysqli_real_escape_string($conn, $_GET['category']);
      $filter = "WHERE category = '$category'";
  }

  $query = "SELECT * FROM products $filter ORDER BY id DESC LIMIT 40";
  $result = mysqli_query($conn, $query);

  while ($product = mysqli_fetch_assoc($result)) {
    $imageUrl = !empty($product['image_url']) ? $product['image_url'] : 'https://placehold.co/180x180/png';

    echo '<div class="product-card">';
    echo '  <a href="product-details.php?id=' . $product['id'] . '" style="text-decoration: none; color: inherit; display: contents;">';
    echo '    <img src="' . $imageUrl . '" alt="' . htmlspecialchars($product['name']) . '">';
    echo '    <div class="product-info">';
    echo '      <h3>' . htmlspecialchars($product['name']) . '</h3>';
    echo '      <p>' . htmlspecialchars($product['description']) . '</p>';
    echo '      <div class="price">$' . number_format($product['price'], 2) . '</div>';
    echo '    </div>';
    echo '  </a>';
    echo '  <form method="POST" action="index.php">';
    echo '    <input type="hidden" name="product_id" value="' . $product['id'] . '">';
    echo '    <button type="submit" name="add_to_cart" class="add-cart-btn">';
echo '      <i class="fas fa-cart-plus"></i> Add to Cart';
echo '    </button>';

    echo '  </form>';
    echo '</div>';
  }
  ?>
</div>

</div>

<footer>
  <div class="container">
    <p>&copy; <?php echo date('Y'); ?> Thrift Store. All rights reserved.</p>
    <div class="footer-links">
      <a href="#">About</a>
      <a href="#">Contact</a>
      <a href="#">Returns</a>
      <a href="#">Terms</a>
    </div>
  </div>
</footer>



</body>
</html>